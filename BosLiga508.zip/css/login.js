﻿(function() {
	const script = document.createElement('script')
	script.src = 'js/jsencrypt.min.js'
	//document.head.append(script)
	document.getElementsByTagName('head')[0].appendChild(script)
})()
$().ready(function ($) {
	$("#txtCode").keyup(function (e) {
		if (e.keyCode === 13) {
			$("#btnSignIn").trigger("click");
		}
	});
	$("#txtCode").focus(function (e) {
		$(this).val('')
	})
	$("#txtCode").blur(function (e) {
		var title = $(this).attr('title')
		$(this).val($(this).val() !== title ? $(this).val() : title)
	})
	// login button Event
	$("#btnSignIn").click(function () {
		var loginData = {
			username: $('#txtUserName').val() || $('#txtUsername').val(),
			password: $('#txtPassword').val(),
			code: $('#txtCode').val()
		}

		var publicKey = '-----BEGIN PUBLIC KEY-----MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCtxCHDjzRjat6R3XaUhVt5ge6lWf2ffo39DZ55gDbx7rYWh3pW/oUv29meZnUw5v0ol43odDzcDC65HZ97yko3TeF0yUS2+DZLHu0+j3pY375SX1ZEV7VM1Ir0Mmj0hJ4dH3F2VYLMBHWPsILSG8/ir68gyynKZUPBfmxm+1iOfQIDAQAB-----END PUBLIC KEY-----'
		var crypt = new JSEncrypt()
		crypt.setKey(publicKey)
		loginData = crypt.encrypt(JSON.stringify(loginData))

		$(this).attr('disabled', 'disabled')
		$.ajax({
			url: 'Login.aspx',
			type: 'POST',
			data: { loginData: loginData, cmd:'login' },
			success: function (responseText) {
				var res = JSON.parse(responseText);
				var success = res.success;
				if (success === true) {
					window.open(res.msg, '_top')
				}
				else {
					switch (res.errCode) {
						case 0:
						case 1:
						case 2:
						case 3:
						case 4:
						case 5:
						case 6:
						case 7:
						case 8:
							alert(res.msg);
							$('#btnSignIn').removeAttr('disabled')
							var title = $('#txtCode').attr('title')
							if (title === undefined || title === '' || title === null)
								title = 'Code'
							$('#txtCode').val(title)
							window.location.reload(true)
							break
					}
				}
			}
		})
	})
})